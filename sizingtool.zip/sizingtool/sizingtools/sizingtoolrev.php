<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Reverse Proxy Sizing</title>
  <link rel="stylesheet" type="text/css" href="sizingtool.css">
  <script src="sorttable.js"></script>
</head>
<body>
 
<?php
	$httpmbps = $_POST['http'];
	$httpsmbps = $_POST['https'];
	$redundancy = $_POST['redundancy'];
	$features = $_POST['features'];
	$sizing = $_POST['sizing'];
	$currentpercent = $_POST['currentpercent'];
	$futuregrowth = $_POST['futuregrowth'];
	$futureyears = $_POST['futureyears'];
	$futurepercent = $_POST['futurepercent'];
	
	/*echo 'HTTP/FTP input is:' . $httpftp;
	echo '<br>HTTPS selected is:' . $https;
	echo '<br>Feature selected is:' . $features;
	echo '<br>Redundancy selected is:' . $redundancy;
	echo '<br>Sizing selected is:' . $sizing;
	echo '<br>Current Percent selected is:' . $currentpercent;
	echo '<br>Future Growth selected is:' . $futuregrowth;
	echo '<br>Future Years selected is:' . $futureyears;
	echo '<br>Future Percent selected is:' . $futurepercent; */
	
echo "<center><H3>&nbsp;</H3></center>";  
	echo "<center><p><a href=\"./sizingtoolrev.html\">Back for new sizing</a></p></center>"; 
	echo "<table width=\"500\" align=\"center\" class=\"nb\">";
	echo "<tr class=\"nb\">";
	echo "<td class=\"titlebar\">";
	echo "&nbsp;&nbsp;&nbsp;ProxySG Sizing Tool";
	echo "</td>";
	echo "</tr>";
	echo "<tr class=\"nb\">";
	echo "<td class=\"nb\">";
	echo "<div id=\"wrapper2\">";
	echo "<h2>Reverse Proxy Sizing Data</h2>";
 
    echo "<table class=\"sortable\" width=\"1000\" align=\"center\">";
	
	echo "<tr>";
	echo "<td>";
	echo "<b title=\"Qty\">Qty</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Model\">Model</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Price\">Total Price</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Throughput (Mbps) per Unit\">Throughput (Mbps) per Unit</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Throughput (Mbps)\">Total Throughput (Mbps)</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Transactions per Second\">TPS</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Transactions per Second\">Total TPS</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Rack Units\">Total Rack Units</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Max Power\">Total Max Power</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Redundant Power\">Redundant Power</b>";	
	echo "</td>";
	echo "</tr>";
	
$dbc = mysqli_connect('127.0.0.1', 'root', 'big1blue', 'perfmatrix')
		or die('Error connecting to MySQL server.');
		
	$query = "SELECT * FROM rev";
	$result = mysqli_query($dbc, $query)
		or die('Error querying database.');
		
	while ($row = mysqli_fetch_array($result)) {
		$model = $row['model'];
		$sgos = $row['sgos'];
		$partnumber = $row['part number'];
		$price = $row['price'];
		$http = $row['http'];
		$https = $row['https'];
		$httptps = $row['httptrans'];
		$httpstps = $row['httpstrans'];
		$maxobjects = $row['max objects'];
		$maxpower = $row['max power'];
		$idlepower = $row['idle power'];
		$redpower = $row['redundant power'];
		$rackunits = $row['rack units'];
/*		echo '<br>model is:' . $model; 
		echo '<br>sgos is:' . $sgos;
		echo '<br>partnumber is:' . $partnumber;
		echo '<br>price is:' . $price;
		echo '<br>users is:' . $users;
		echo '<br>http is:' . $http;
		echo '<br>httppolicy is:' . $httppolicy;
		echo '<br>httppolicyicap is:' . $httppolicyicap;
		echo '<br>httppolicyicaphttps is:' . $httppolicyicaphttps;
		echo '<br>httptps is:' . $httptps;
		echo '<br>httppolicytps is:' . $httppolicytps;
		echo '<br>httppolicyicaptps is:' . $httppolicyicaptps;
		echo '<br>httppolicyicaphttpstps is:' . $httppolicyicaphttpstps;
		echo '<br>maxobjects is:' . $maxobjects;
		echo '<br>maxclientconnections is:' . $maxclientconnections;
		echo '<br>maxpower is:' . $maxpower;
		echo '<br>idlepower is:' . $idlepower;
		echo '<br>redpower is:' . $redpower;
		echo '<br>rackunits is:' . $rackunits; */
		
		/*this is the main logic*/
		
		if ($sizing == 'future') {
			$currentpercent = ( $futurepercent / (pow((1 + ($futuregrowth / 100)), $futureyears )));
		}
			
		if ($features == 'http') {
			$qty = ceil(($httpmbps / $http) / ($currentpercent / 100));
			$throughput = $http;
			$totalthroughput = ($qty * $http);
			$tps = $httptps;
			$totaltps = ($qty * $httptps);
		}
		
		if ($features == 'https') {
			$qty = ceil(($httpsmbps / $https) / ($currentpercent / 100));
			$throughput = $https;
			$totalthroughput = ($qty * $https);
			$tps = $httpstps;
			$totaltps = ($qty * $httpstps);
		}
		
		if ($redundancy == 'nplus1') {
			$qty++;
		}
		
		$totalprice = ( $qty * $price ); 
		$totalru = ($qty * $rackunits);
		$totalmaxpower = ($qty * $maxpower);
		
		if ($redpower == 0) {
			$redundantpower = 'no';
		}
		else {
			$redundantpower = "yes";
		}
		
		echo "<tr>";
		echo "<td>";
	echo "<b title=\"Qty\">" . $qty . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Model\">" . $model . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Price\">" . $totalprice . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Throughput (Mbps) per Unit\">" . $throughput . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Throughput (Mbps)\">" . $totalthroughput . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Transactions per Second\">" . $tps . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Transactions per Second\">" . $totaltps . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Rack Units\">" . $totalru . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Total Max Power\">" . $totalmaxpower . "</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Redundant Power\">" . $redundantpower . "</b>";	
	echo "</td>";
	echo "</tr>";
	} 
	
	mysqli_close($dbc); 
	
	echo "</table>";

	echo "</div>";
	echo "</td>";
	echo "</tr>";
	echo "</table>";
	
?>

</body>
</html>
