<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>File Upload</title>
  <link rel="stylesheet" type="text/css" href="sysinfoviewer.css">
  <script type="text/javascript">
 function unhide(divID) {
 var item = document.getElementById(divID);
 if (item) {
 item.className=(item.className=='hidden')?'unhidden':'hidden';
 }
 }
 </script>
</head>
<body>

<form enctype="multipart/form-data" action="../sizingtools/sizingtoolfwd.php" method="POST">
 
<?php
 $target_path = "uploads/";
 $file_uploaded = False;

$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 

if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
    $file_uploaded = True;
//    echo "The file ".  basename( $_FILES['uploadedfile']['name']). 
//    " has been uploaded <br>";
} else{
    echo "There was an error uploading the file, please try again!";
}

if($file_uploaded) {
	$fh = fopen($target_path, 'r') or die("Can't open file");
//	echo "opened file successfully <br>";

	echo "<center><H3>&nbsp;</H3></center>";  
	echo "<center><p><a href=\"./sysinfosizingextractor.html\">Back for new sizing</a></p></center>"; 
	echo "<table width=\"500\" align=\"center\" class=\"nb\">";
	echo "<tr class=\"nb\">";
	echo "<td class=\"titlebar\">";
	echo "&nbsp;&nbsp;&nbsp;Sysinfo Sizing Data Extraction Tool";
	echo "</td>";
	echo "</tr>";
	echo "<tr class=\"nb\">";
	echo "<td class=\"nb\">";
	echo "<div id=\"wrapper2\">";
	echo "<h2>Forward Proxy Sizing Data</h2>";
	echo "<p><a href=\"javascript:unhide('fwd_details');\">Click Here for Details</a></p>";
	echo "<div id=\"fwd_details\" class=\"hidden\">";
	echo "<p>User Count and Peak Intercepted Hourly Bandwidth (which represents all intercepted traffic for the last hour - so it is critical to capture this data within an hour after the customers peak traffic time) are the numbers that should be used for the standard Forward Proxy Sizing Guide but HTTP, HTTPS, FTP and other service numbers are shown for reference.  The worker count is good to use to verify that that proposed platform can handle the required number of workers.  Platform worker data can be found in the performance matrix</p>";
	echo "</div>";
	
    while ($line= fgets ($fh)) {

//get peak user count
	if (preg_match("/users:current~weekly/", $line)) {
		$weeklyUserChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyUserChunks[$i]);
		}
		if ( $peakUser < max($weeklyUserChunks)) {
			$peakUser = max($weeklyUserChunks);
		}
	}

//get peak DS client Mbps hourly
	if (preg_match("/svc:ds:service:intercepted_client_bytes~hourly/", $line)) {
		$hourlyDSChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyDSChunks[$i]);
		}
		if ( $peakHourlyDSClientBytes < max($hourlyDSChunks)) {
			$peakHourlyDSClientBytes = max($hourlyDSChunks);
			$peakHourlyDSClientMbits = ($peakHourlyDSClientBytes / 7500000);
		}
	}
	
//get peak DS client Mbps weekly
	if (preg_match("/svc:ds:service:intercepted_client_bytes~weekly/", $line)) {
		$weeklyDSChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyDSChunks[$i]);
		}
		if ( $peakWeeklyDSClientBytes < max($weeklyDSChunks)) {
			$peakWeeklyDSClientBytes = max($weeklyDSChunks);
			$peakWeeklyDSClientMbits = ($peakWeeklyDSClientBytes / 10800000000);
		}
	}
	
//get peak Bypassed DS client Mbps hourly
	if (preg_match("/svc:ds:service:bypassed_bytes~hourly/", $line)) {
		$hourlyBypassDSChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyBypassDSChunks[$i]);
		}
		if ( $peakHourlyBypassDSClientBytes < max($hourlyBypassDSChunks)) {
			$peakHourlyBypassDSClientBytes = max($hourlyBypassDSChunks);
			$peakHourlyBypassDSClientMbits = ($peakHourlyBypassDSClientBytes / 7500000);
		}
	}
	
//get peak Bypassed DS client Mbps weekly
	if (preg_match("/svc:ds:service:bypassed_bytes~weekly/", $line)) {
		$weeklyBypassDSChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyBypassDSChunks[$i]);
		}
		if ( $peakWeeklyBypassDSClientBytes < max($weeklyBypassDSChunks)) {
			$peakWeeklyBypassDSClientBytes = max($weeklyBypassDSChunks);
			$peakWeeklyBypassDSClientMbits = ($peakWeeklyBypassDSClientBytes / 10800000000);
		}
	}
	
//get peak HTTP client Mbps hourly
	if (preg_match("/svc:proxy:HTTP:intercepted_client_bytes~hourly/", $line)) {
		$hourlyHttpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyHttpChunks[$i]);
		}
		if ( $peakHourlyHttpClientBytes < max($hourlyHttpChunks)) {
			$peakHourlyHttpClientBytes = max($hourlyHttpChunks);
			$peakHourlyHttpClientMbits = ($peakHourlyHttpClientBytes / 7500000);
		}
	}
	
//get peak HTTP client Mbps weekly
	if (preg_match("/svc:proxy:HTTP:intercepted_client_bytes~weekly/", $line)) {
		$weeklyHttpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyHttpChunks[$i]);
		}
		if ( $peakWeeklyHttpClientBytes < max($weeklyHttpChunks)) {
			$peakWeeklyHttpClientBytes = max($weeklyHttpChunks);
			$peakWeeklyHttpClientMbits = ($peakWeeklyHttpClientBytes / 10800000000);
		}
	}
	
//get peak HTTPS client Mbps hourly
	if (preg_match("/svc:proxy:SSL:intercepted_client_bytes~hourly/", $line)) {
		$hourlyHttpsChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyHttpsChunks[$i]);
		}
		if ( $peakHourlyHttpsClientBytes < max($hourlyHttpsChunks)) {
			$peakHourlyHttpsClientBytes = max($hourlyHttpsChunks);
			$peakHourlyHttpsClientMbits = ($peakHourlyHttpsClientBytes / 7500000);
		}
	}
	
//get peak HTTPS client Mbps weekly
	if (preg_match("/svc:proxy:SSL:intercepted_client_bytes~weekly/", $line)) {
		$weeklyHttpsChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyHttpsChunks[$i]);
		}
		if ( $peakWeeklyHttpsClientBytes < max($weeklyHttpsChunks)) {
			$peakWeeklyHttpsClientBytes = max($weeklyHttpsChunks);
			$peakWeeklyHttpsClientMbits = ($peakWeeklyHttpsClientBytes / 10800000000);
		}
	}
	
//get peak TCP Tunnel client Mbps hourly
	if (preg_match("/svc:proxy:TCP Tunnel:intercepted_client_bytes~hourly/", $line)) {
		$hourlyTcpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyTcpChunks[$i]);
		}
		if ( $peakHourlyTcpClientBytes < max($hourlyTcpChunks)) {
			$peakHourlyTcpClientBytes = max($hourlyTcpChunks);
			$peakHourlyTcpClientMbits = ($peakHourlyTcpClientBytes / 7500000);
		}
	}
	
//get peak TCP Tunnel client Mbps weekly
	if (preg_match("/svc:proxy:TCP Tunnel:intercepted_client_bytes~weekly/", $line)) {
		$weeklyTcpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyTcpChunks[$i]);
		}
		if ( $peakWeeklyTcpClientBytes < max($weeklyTcpChunks)) {
			$peakWeeklyTcpClientBytes = max($weeklyTcpChunks);
			$peakWeeklyTcpClientMbits = ($peakWeeklyTcpClientBytes / 10800000000);
		}
	}
	
//get peak FTP client Mbps hourly
	if (preg_match("/svc:proxy:FTP:intercepted_client_bytes~hourly/", $line)) {
		$hourlyFtpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyFtpChunks[$i]);
		}
		if ( $peakHourlyFtpClientBytes < max($hourlyFtpChunks)) {
			$peakHourlyFtpClientBytes = max($hourlyFtpChunks);
			$peakHourlyFtpClientMbits = ($peakHourlyFtpClientBytes / 7500000);
		}
	}
	
//get peak FTP client Mbps weekly
	if (preg_match("/svc:proxy:FTP:intercepted_client_bytes~weekly/", $line)) {
		$weeklyFtpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyFtpChunks[$i]);
		}
		if ( $peakWeeklyFtpClientBytes < max($weeklyFtpChunks)) {
			$peakWeeklyFtpClientBytes = max($weeklyFtpChunks);
			$peakWeeklyFtpClientMbits = ($peakWeeklyFtpClientBytes / 10800000000);
		}
	}
	
//get peak Flash client Mbps hourly
	if (preg_match("/svc:proxy:Flash:intercepted_client_bytes~hourly/", $line)) {
		$hourlyFlashChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyFlashChunks[$i]);
		}
		if ( $peakHourlyFlashClientBytes < max($hourlyFlashChunks)) {
			$peakHourlyFlashClientBytes = max($hourlyFlashChunks);
			$peakHourlyFlashClientMbits = ($peakHourlyFlashClientBytes / 7500000);
		}
	}
	
//get peak Flash client Mbps weekly
	if (preg_match("/svc:proxy:Flash:intercepted_client_bytes~weekly/", $line)) {
		$weeklyFlashChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyFlashChunks[$i]);
		}
		if ( $peakWeeklyFlashClientBytes < max($weeklyFlashChunks)) {
			$peakWeeklyFlashClientBytes = max($weeklyFlashChunks);
			$peakWeeklyFlashClientMbits = ($peakWeeklyFlashClientBytes / 10800000000);
		}
	}
	
//get peak RTSP client Mbps hourly
	if (preg_match("/svc:proxy:RTSP:intercepted_client_bytes~hourly/", $line)) {
		$hourlyRtspChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyRtspChunks[$i]);
		}
		if ( $peakHourlyRtspClientBytes < max($hourlyRtspChunks)) {
			$peakHourlyRtspClientBytes = max($hourlyRtspChunks);
			$peakHourlyRtspClientMbits = ($peakHourlyRtspClientBytes / 7500000);
		}
	}
	
//get peak RTSP client Mbps weekly
	if (preg_match("/svc:proxy:RTSP:intercepted_client_bytes~weekly/", $line)) {
		$weeklyRtspChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyRtspChunks[$i]);
		}
		if ( $peakWeeklyRtspClientBytes < max($weeklyRtspChunks)) {
			$peakWeeklyRtspClientBytes = max($weeklyRtspChunks);
			$peakWeeklyRtspClientMbits = ($peakWeeklyRtspClientBytes / 10800000000);
		}
	}
	
//get peak WMP client Mbps hourly
	if (preg_match("/svc:proxy:Windows Media:intercepted_client_bytes~hourly/", $line)) {
		$hourlyWmpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyWmpChunks[$i]);
		}
		if ( $peakHourlyWmpClientBytes < max($hourlyWmpChunks)) {
			$peakHourlyWmpClientBytes = max($hourlyWmpChunks);
			$peakHourlyWmpClientMbits = ($peakHourlyWmpClientBytes / 7500000);
		}
	}
	
//get peak WMP client Mbps weekly
	if (preg_match("/svc:proxy:Windows Media:intercepted_client_bytes~weekly/", $line)) {
		$weeklyWmpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyWmpChunks[$i]);
		}
		if ( $peakWeeklyWmpClientBytes < max($weeklyWmpChunks)) {
			$peakWeeklyWmpClientBytes = max($weeklyWmpChunks);
			$peakWeeklyWmpClientMbits = ($peakWeeklyWmpClientBytes / 10800000000);
		}
	}
	
//get peak WMP client Mbps hourly
	if (preg_match("/svc:proxy:Windows Media:intercepted_client_bytes~hourly/", $line)) {
		$hourlyWmpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyWmpChunks[$i]);
		}
		if ( $peakHourlyWmpClientBytes < max($hourlyWmpChunks)) {
			$peakHourlyWmpClientBytes = max($hourlyWmpChunks);
			$peakHourlyWmpClientMbits = ($peakHourlyWmpClientBytes / 7500000);
		}
	}
	
//get peak WMP client Mbps weekly
	if (preg_match("/svc:proxy:Windows Media:intercepted_client_bytes~weekly/", $line)) {
		$weeklyWmpChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyWmpChunks[$i]);
		}
		if ( $peakWeeklyWmpClientBytes < max($weeklyWmpChunks)) {
			$peakWeeklyWmpClientBytes = max($weeklyWmpChunks);
			$peakWeeklyWmpClientMbits = ($peakWeeklyWmpClientBytes / 10800000000);
		}
	}
	
//get peak Real client Mbps hourly
	if (preg_match("/svc:proxy:Real Media:intercepted_client_bytes~hourly/", $line)) {
		$hourlyRealChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyRealChunks[$i]);
		}
		if ( $peakHourlyRealClientBytes < max($hourlyRealChunks)) {
			$peakHourlyRealClientBytes = max($hourlyRealChunks);
			$peakHourlyRealClientMbits = ($peakHourlyRealClientBytes / 7500000);
		}
	}
	
//get peak Real client Mbps weekly
	if (preg_match("/svc:proxy:Real Media:intercepted_client_bytes~weekly/", $line)) {
		$weeklyRealChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyRealChunks[$i]);
		}
		if ( $peakWeeklyRealClientBytes < max($weeklyRealChunks)) {
			$peakWeeklyRealClientBytes = max($weeklyRealChunks);
			$peakWeeklyRealClientMbits = ($peakWeeklyRealClientBytes / 10800000000);
		}
	}
	
//get peak QT client Mbps hourly
	if (preg_match("/svc:proxy:QuickTime:intercepted_client_bytes~hourly/", $line)) {
		$hourlyQtChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyQtChunks[$i]);
		}
		if ( $peakHourlyQtClientBytes < max($hourlyQtChunks)) {
			$peakHourlyQtClientBytes = max($hourlyQtChunks);
			$peakHourlyQtClientMbits = ($peakHourlyQtClientBytes / 7500000);
		}
	}
	
//get peak QT client Mbps weekly
	if (preg_match("/svc:proxy:QuickTime:intercepted_client_bytes~weekly/", $line)) {
		$weeklyQtChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyQtChunks[$i]);
		}
		if ( $peakWeeklyQtClientBytes < max($weeklyQtChunks)) {
			$peakWeeklyQtClientBytes = max($weeklyQtChunks);
			$peakWeeklyQtClientMbits = ($peakWeeklyQtClientBytes / 10800000000);
		}
	}

//get peak cpu hourly
	if (preg_match("/system:cpu-usage~hourly/", $line)) {
		$hourlyCpuChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyCpuChunks[$i]);
		}
		if ( $peakHourlyCpu < max($hourlyCpuChunks)) {
			$peakHourlyCpu = max($hourlyCpuChunks);
		}
	}
	
//get peak cpu weekly
	if (preg_match("/system:cpu-usage~weekly/", $line)) {
		$weeklyCpuChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyCpuChunks[$i]);
		}
		if ( $peakWeeklyCpu < max($weeklyCpuChunks)) {
			$peakWeeklyCpu = max($weeklyCpuChunks);
		}
	}
	
//calculate peak streaming data
$peakHourlyStreamingClientMbits = $peakHourlyFlashClientMbits + $peakHourlyRtspClientMbits + $peakHourlyWmpClientMbits + $peakHourlyQtClientMbits;
$peakWeeklyStreamingClientMbits = $peakWeeklyFlashClientMbits + $peakWeeklyRtspClientMbits + $peakWeeklyWmpClientMbits + $peakWeeklyQtClientMbits;
	
//get the peak client worker count
      	if (preg_match("/HTTP_MAIN_0103/", $line)) {
		$clientChunks = explode(" ", $line);
		$thisMaxClients = $clientChunks[6];
		if ( $MaxClients < $thisMaxClients) {
			$MaxClients = $thisMaxClients;
    	}
		}	
		
    }
    
    echo "<b>Peak User Count (Weekly): " . $peakUser . "<br><br></b>";	
    echo "<table width=\"500\" align=\"center\">";
	echo "<tr>";
	echo "<td>";
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Hourly is the peak per-minute sample from the last hour.  This is your best measure for sizing but would need to be taken within an hour of the peak traffic for a customer to capture the correct data.  The easiest way to do this is using snapshots.\">Hourly</b>";	
	echo "</td>";
	echo "<td>";
	echo "<b title=\"Weekly is a roll up and reaveraging of Daily (which is a roll up of Hourly) per-day samples for the last week NOT the peak per-minute sample from the Week\">Weekly</b>";	
	echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<b title=\"CPU\">Peak CPU</b>";
    echo "</td>";
    echo "<td>";
    echo "<b>" . round($peakHourlyCpu, 2) . "</b>";
    echo "</td>";
     echo "<td>";
    echo "<b>" . round($peakWeeklyCpu, 2) . "</b>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<b title=\"all intercepted traffic\">Peak Intercepted client Mbps</b>";
    echo "</td>";
    echo "<td>";
    echo "<b>" . round($peakHourlyDSClientMbits, 2) . "</b>";
    echo "</td>";
     echo "<td>";
    echo "<b>" . round($peakWeeklyDSClientMbits, 2) . "</b>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<i title=\"all intercepted HTTP traffic\">Peak HTTP client Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyHttpClientMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyHttpClientMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<i title=\"all intercepted HTTPS traffic\">Peak HTTPS client Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyHttpsClientMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyHttpsClientMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<i title=\"all intercepted FTP traffic\">Peak FTP client Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyFtpClientMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyFtpClientMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<i title=\"all intercepted TCP Tunneled traffic\">Peak TCP Tunnel client Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyTcpClientMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyTcpClientMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<i title=\"all intercepted Streaming traffic (RTMP, RTSP, WMP, RMP, QT)\">Peak Streaming client Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyStreamingClientMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyStreamingClientMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
		echo "<tr>";
	echo "<td>";
    echo "<i title=\"all bypassed traffic\">Peak Bypassed Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyBypassDSClientMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyBypassDSClientMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
	echo "</table>";
	echo "<br><i>Peak Client Worker Count: " . $MaxClients . "<br></i>";
	
	fclose($fh);
}

if($file_uploaded) {
	$fh = fopen($target_path, 'r') or die("Can't open file");
//	echo "opened file successfully <br>";
	
//	$ln= 0;

	echo "<h2>WAN Acceleration Sizing Data</h2>";
	echo "<p><a href=\"javascript:unhide('acceleration_details');\">Click Here for Details</a></p>";
	echo "<div id=\"acceleration_details\" class=\"hidden\">";
	echo "<p>ADN sizing is based on bi-directional WAN bandwidth, not LAN bandwidth, and our sizing is based on an assumption of 3:1 compression.  So sizing is best done by averaging BDC:inbound/outbound-compressed but you will want to verify BDC:inbound/outbound-uncompressed show close to 3:1 compression. Also, this assumes that all of the traffic is going over ADN so if traffic is intercepted but not optimized (ie ADN enabled) then it should be added into the bandwidth numbers.  The most common example of this would be streaming protocols (RTSP, RTMP, MMS)</p>";
	echo "</div>";

    while ($line= fgets ($fh)) {
  //      ++$ln;

//get adn tunnel count
	if (preg_match('/adn:traffic:total:connections~weekly/', $line)) {
		$weeklyAdnChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyAdnChunks[$i]);
		}
		if ( $peakAdn < max($weeklyAdnChunks)) {
			$peakAdn = max($weeklyAdnChunks);
		}
	}
	
//get bdc inbound uncompressed hourly
	if (preg_match('/BDC:inbound-uncompressed~hourly/', $line)) {
		$hourlyBdcInUnChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyBdcInUnChunks[$i]);
		}
		if ( $peakHourlyBdcInUnBytes < max($hourlyBdcInUnChunks)) {
			$peakHourlyBdcInUnBytes = max($hourlyBdcInUnChunks);
			$peakHourlyBdcInUnMbits = ($peakHourlyBdcInUnBytes / 7500000);
		}
	}
	
//get bdc outbound uncompressed hourly
	if (preg_match('/BDC:outbound-uncompressed~hourly/', $line)) {
		$hourlyBdcOutUnChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyBdcOutUnChunks[$i]);
		}
		if ( $peakHourlyBdcOutUnBytes < max($hourlyBdcOutUnChunks)) {
			$peakHourlyBdcOutUnBytes = max($hourlyBdcOutUnChunks);
			$peakHourlyBdcOutUnMbits = ($peakHourlyBdcOutUnBytes / 7500000);
		}
	}
	
//get bdc inbound compressed hourly
	if (preg_match('/BDC:inbound-compressed~hourly/', $line)) {
		$hourlyBdcInChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyBdcInChunks[$i]);
		}
		if ( $peakHourlyBdcInBytes < max($hourlyBdcInChunks)) {
			$peakHourlyBdcInBytes = max($hourlyBdcInChunks);
			$peakHourlyBdcInMbits = ($peakHourlyBdcInBytes / 7500000);
		}
	}
	
//get bdc outbound compressed hourly
	if (preg_match('/BDC:outbound-compressed~hourly/', $line)) {
		$hourlyBdcOutChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyBdcOutChunks[$i]);
		}
		if ( $peakHourlyBdcOutBytes < max($hourlyBdcOutChunks)) {
			$peakHourlyBdcOutBytes = max($hourlyBdcOutChunks);
			$peakHourlyBdcOutMbits = ($peakHourlyBdcOutBytes / 7500000);
		}
	}

//get bdc inbound uncompressed weekly
	if (preg_match('/BDC:inbound-uncompressed~weekly/', $line)) {
		$weeklyBdcInUnChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyBdcInUnChunks[$i]);
		}
		if ( $peakWeeklyBdcInUnBytes < max($weeklyBdcInUnChunks)) {
			$peakWeeklyBdcInUnBytes = max($weeklyBdcInUnChunks);
			$peakWeeklyBdcInUnMbits = ($peakWeeklyBdcInUnBytes / 10800000000);	
		}
	}
	
//get bdc outbound uncompressed weekly
	if (preg_match('/BDC:outbound-uncompressed~weekly/', $line)) {
		$weeklyBdcOutUnChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyBdcOutUnChunks[$i]);
		}
		if ( $peakWeeklyBdcOutUnBytes < max($weeklyBdcOutUnChunks)) {
			$peakWeeklyBdcOutUnBytes = max($weeklyBdcOutUnChunks);
			$peakWeeklyBdcOutUnMbits = ($peakWeeklyBdcOutUnBytes / 10800000000);
		}
	}
	
//get bdc inbound compressed weekly
	if (preg_match('/BDC:inbound-compressed~weekly/', $line)) {
		$weeklyBdcInChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyBdcInChunks[$i]);
		}
		if ( $peakWeeklyBdcInBytes < max($weeklyBdcInChunks)) {
			$peakWeeklyBdcInBytes = max($weeklyBdcInChunks);
			$peakWeeklyBdcInMbits = ($peakWeeklyBdcInBytes / 10800000000);
		}
	}
	
//get bdc outbound compressed weekly
	if (preg_match('/BDC:outbound-compressed~weekly/', $line)) {
		$weeklyBdcOutChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyBdcOutChunks[$i]);
		}
		if ( $peakWeeklyBdcOutBytes < max($weeklyBdcOutChunks)) {
			$peakWeeklyBdcOutBytes = max($weeklyBdcOutChunks);
			$peakWeeklyBdcOutMbits = ($peakWeeklyBdcOutBytes / 10800000000);
		}
	}
    
    }
    
    echo "<b>Peak ADN Connection Count (Weekly): " . $peakAdn . "<br><br></b>";	
  
    echo "<table width=\"500\" align=\"center\">";
	echo "<tr>";
	echo "<td>";
	echo "</td>";
	echo "<td>";
	echo "Hourly";	
	echo "</td>";
	echo "<td>";
	echo "Weekly";	
	echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<b>Peak BDC inbound compressed Mbps</b>";
    echo "</td>";
    echo "<td>";
    echo "<b>" . round($peakHourlyBdcInMbits, 2) . "</b>";
    echo "</td>";
     echo "<td>";
    echo "<b>" . round($peakWeeklyBdcInMbits, 2) . "</b>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<b>Peak BDC outbound compressed Mbps</b>";
    echo "</td>";
    echo "<td>";
    echo "<b>" . round($peakHourlyBdcOutMbits, 2) . "</b>";
    echo "</td>";
     echo "<td>";
    echo "<b>" . round($peakWeeklyBdcOutMbits, 2) . "</b>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<i>Peak BDC inbound uncompressed Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyBdcInUnMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyBdcInUnMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
    echo "<i>Peak BDC outbound uncompressed Mbps</i>";
    echo "</td>";
    echo "<td>";
    echo "<i>" . round($peakHourlyBdcOutUnMbits, 2) . "</i>";
    echo "</td>";
     echo "<td>";
    echo "<i>" . round($peakWeeklyBdcOutUnMbits, 2) . "</i>";
    echo "</td>";
	echo "</tr>";
	echo "</table>";
	
	fclose($fh);
}
	
if($file_uploaded) {
	$fh = fopen($target_path, 'r') or die("Can't open file");
//	echo "opened file successfully <br>";
	
//	$ln= 0;

	echo "<h2>Reverse Proxy Sizing Data</h2>";
	echo "<p><a href=\"javascript:unhide('rp_details');\">Click Here for Details</a></p>";
	echo "<div id=\"rp_details\" class=\"hidden\">";
	echo "<p>The HTTPS number can be used if only HTTPS Reverse Proxy is being done.  This will not include any other services (ie HTTP, FTP) that are being used for Reverse Proxy.  The max objects are not generally used for sizing but it is recommended that one verifies that the Proxy SG selected can handle the number of objects that the customer requires.</p>";
	echo "</div>";

    while ($line= fgets ($fh)) {
  //      ++$ln;

//get the peak client worker count
      	if (preg_match("/CEGEN1 /", $line)) {
		$objectChunks = explode(" ", $line);
		if ( $maxObjects < $objectChunks[14]) {
			$maxObjects = $objectChunks[14];
		}
		}	

//get https reverse proxy client bytes hourly
	if (preg_match('/svc:proxy:HTTPS Reverse Proxy:intercepted_client_bytes~hourly/', $line)) {
		$hourlyHttpsRevClientChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($hourlyHttpsRevClientChunks[$i]);
		}
		if ( $peakHourlyHttpsRevClientBytes < max($hourlyHttpsRevClientChunks)) {
			$peakHourlyHttpsRevClientBytes = max($hourlyHttpsRevClientChunks);
			$peakHourlyHttpsRevClientMbits = ($peakHourlyHttpsRevClientBytes / 7500000);
		}
	}    
    
//get https reverse proxy client bytes weekly
	if (preg_match('/svc:proxy:HTTPS Reverse Proxy:intercepted_client_bytes~weekly/', $line)) {
		$weeklyHttpsRevClientChunks = explode(" ", $line);
		for($i = 0; $i <= 6; $i++){
		unset($weeklyHttpsRevClientChunks[$i]);
		}
		if ( $peakHttpsRevClientBytes < max($weeklyHttpsRevClientChunks)) {
			$peakHttpsRevClientBytes = max($weeklyHttpsRevClientChunks);
			$peakHttpsRevClientMBytes = ($peakHttpsRevClientBytes / 10800000000);
		}
	}
	}
    
    echo "<b>Peak HTTPS Reverse Proxy Client Mbps (Hourly): " . round($peakHourlyHttpsRevClientMbits, 2) . "<br></b>";	
    echo "<b>Peak HTTPS Reverse Proxy Client Mbps (Weekly): " . round($peakHttpsRevClientMBytes, 2) . "<br></b>";	
    echo "<i>Max Objects: " . $maxObjects . "<br></i>";
    
	fclose($fh);
}	

	echo "&nbsp;&nbsp;&nbsp;";
	echo "</div>";
	echo "</td>";
	echo "</tr>";
	echo "</table>";
	
	$httpftp = $peakHourlyHttpClientMbits + $peakHourlyFtpClientMbits;
	$https = $peakHourlyHttpsClientMbits;
	
	echo "<input type=\"hidden\" name=\"httpftp\" value=\"" . $httpftp . "\" />";
	echo "<input type=\"hidden\" name=\"https\" value=\"" . $https . "\" />";
	
	/*}*/
	
?>

	<center>
	<br><input type="submit" name="SGfwdextractor" value="SG Sizing" />
	</center>
	</form>
	
</body>
</html>
