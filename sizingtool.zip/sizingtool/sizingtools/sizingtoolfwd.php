<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Forward Proxy Sizing</title>
  <link rel="stylesheet" type="text/css" href="sizingtool.css">
  <script src="sorttable.js"></script>
</head>
<body>
 
<?php

$output_form = true;
$activeconn = 10; //number of tcp connections use by active web surfers
$idleconn = 2; //number of tcp connections used by idle web surfers - weather bug etc
$percentactive = .2;
$percentidle = .8;

/*SG CSV output logic*/
if (isset($_POST['SGfwdcsvsubmit'])) {
	$sizingbasis = $_POST['sizingbasis'];
	$httpftp = $_POST['httpftp'];
	$https = $_POST['https'];
	$concurrentsizing = $_POST['concurrentusers'];
	$userssizing = $_POST['users'];
	$tpssizing = $_POST['tps'];
	$redundancy = $_POST['redundancy'];
	$features = $_POST['features'];
	$sizing = $_POST['sizing'];
	$currentpercent = $_POST['currentpercent'];
	$futuregrowth = $_POST['futuregrowth'];
	$futureyears = $_POST['futureyears'];
	$futurepercent = $_POST['futurepercent'];
	$codeversion = $_POST['codeversion'];
	$outputcols = $_POST['outputcols'];
	$output_form = false;
	
	echo "Quantity" . "," . "Model" . "," . "Total Price" . "<br>";	
	
	$dbc = mysqli_connect('127.0.0.1', 'root', 'big1blue', 'perfmatrix')
		or die('Error connecting to MySQL server.');
		
	$query = "SELECT * FROM fwd";
	$result = mysqli_query($dbc, $query)
		or die('Error querying database.');
		
	while ($row = mysqli_fetch_array($result)) {
		$model = $row['model'];
		$sgos = $row['sgos'];
		$partnumber = $row['part number'];
		$price = $row['price'];
		$users = $row['users'];
		$http = $row['http'];
		$httppolicy = $row['httppolicy'];
		$httppolicyicap = $row['httppolicyicap'];
		$httppolicyicaphttps = $row['httppolicyicaphttps'];
		$httptps = $row['httptps'];
		$httppolicytps = $row['httppolicytps'];
		$httppolicyicaptps = $row['httppolicyicaptps'];
		$httppolicyicaphttpstps = $row['httppolicyicaphttpstps'];
		$maxobjects = $row['max objects'];
		$maxclientconnections = $row['max client connections'];
		$maxpower = $row['max power'];
		$idlepower = $row['idle power'];
		$redpower = $row['redundant power'];
		$rackunits = $row['rack units'];
/*		echo '<br>model is:' . $model; 
		echo '<br>sgos is:' . $sgos;
		echo '<br>partnumber is:' . $partnumber;
		echo '<br>price is:' . $price;
		echo '<br>users is:' . $users;
		echo '<br>http is:' . $http;
		echo '<br>httppolicy is:' . $httppolicy;
		echo '<br>httppolicyicap is:' . $httppolicyicap;
		echo '<br>httppolicyicaphttps is:' . $httppolicyicaphttps;
		echo '<br>httptps is:' . $httptps;
		echo '<br>httppolicytps is:' . $httppolicytps;
		echo '<br>httppolicyicaptps is:' . $httppolicyicaptps;
		echo '<br>httppolicyicaphttpstps is:' . $httppolicyicaphttpstps;
		echo '<br>maxobjects is:' . $maxobjects;
		echo '<br>maxclientconnections is:' . $maxclientconnections;
		echo '<br>maxpower is:' . $maxpower;
		echo '<br>idlepower is:' . $idlepower;
		echo '<br>redpower is:' . $redpower;
		echo '<br>rackunits is:' . $rackunits; */
		
		$calculatedconnections = ((($concurrentsizing * $percentactive) * $activeconn) + (($concurrentsizing * $percentidle) * $idleconn));
		
		if ($codeversion == $sgos) { 
		
		if ($sizing == 'future') {
			$currentpercent = ( $futurepercent / (pow((1 + ($futuregrowth / 100)), $futureyears )));
		}
			
		if ($features == 'httponly') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil(($httpftp / $http) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httptps) / ($currentpercent / 70));
			}
			$throughput = $http;
			$totalthroughput = ($qty * $http);
			$tps = $httptps;
			$totaltps = ($qty * $httptps);
		}
		
		if ($features == 'httppolicy') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil(($httpftp / $httppolicy) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httppolicytps) / ($currentpercent / 70));
			}
			$throughput = $httppolicy;
			$totalthroughput = ($qty * $httppolicy);
			$tps = $httppolicytps;
			$totaltps = ($qty * $httppolicytps);
		}
		
		if ($features == 'httppolicyicap') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil(($httpftp / $httppolicyicap) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httppolicyicaptps) / ($currentpercent / 70));
			}
			$throughput = $httppolicyicap;
			$totalthroughput = ($qty * $httppolicyicap);
			$tps = $httppolicyicaptps;
			$totaltps = ($qty * $httppolicyicaptps);
		}
		
		if ($features == 'httppolicyicaphttps') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil((($httpftp + $https) / $httppolicyicaphttps) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httppolicyicaphttpstps) / ($currentpercent / 70));
			}
			$throughput = $httppolicyicaphttps;
			$totalthroughput = ($qty * $httppolicyicaphttps);
			$tps = $httppolicyicaphttpstps;
			$totaltps = ($qty * $httppolicyicaphttpstps);
		}
		
		$totalusers = ($qty * $users);
		$totalworkers = ($qty * $maxclientconnections);
		
		if ($redundancy == 'nplus1') {
			$qty++;
		}
		
		$totalprice = ( $qty * $price ); 
		$totalru = ($qty * $rackunits);
		$totalmaxpower = ($qty * $maxpower);
		
		if ($redpower == 0) {
			$redundantpower = 'no';
		}
		else {
			$redundantpower = "yes";
		}
		}
		
		echo $qty . "," . $partnumber . "," . $totalprice . "<br>";	
	}
} 

/*AV CSV output logic*/
if (isset($_POST['AVfwdcsvsubmit'])) {
	$httpftp = $_POST['httpftp'];
	$https = $_POST['https'];
	$redundancy = $_POST['redundancy'];
	$features = $_POST['features'];
	$sizing = $_POST['sizing'];
	$currentpercent = $_POST['currentpercent'];
	$futuregrowth = $_POST['futuregrowth'];
	$futureyears = $_POST['futureyears'];
	$futurepercent = $_POST['futurepercent'];
	$codeversion = $_POST['codeversion'];
	$outputcols = $_POST['outputcols'];
	$output_form = false;
	
	echo "Quantity" . "," . "Model" . "," . "Total Price" . "<br>";	
	
	$dbc = mysqli_connect('127.0.0.1', 'root', 'big1blue', 'perfmatrix')
		or die('Error connecting to MySQL server.');
		
	$query = "SELECT * FROM av";
	$result = mysqli_query($dbc, $query)
		or die('Error querying database.');
		
	while ($row = mysqli_fetch_array($result)) {
		$model = $row['model'];
		$partnumber = $row['part'];
		$tput = $row['tput'];
		$price = $row['price'];
		$rackunits = $row['ru'];
		$maxpower = $row['max power'];
		$redpower = $row['redundant'];
	
		/*this is the main logic*/
		
		if ($sizing == 'future') {
			$currentpercent = ( $futurepercent / (pow((1 + ($futuregrowth / 100)), $futureyears )));
		}
			
		if ($features == 'httponly') {
			$qty = ceil(($httpftp / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($features == 'httppolicy') {
			$qty = ceil(($httpftp / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($features == 'httppolicyicap') {
			$qty = ceil(($httpftp / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($features == 'httppolicyicaphttps') {
			$qty = ceil((($httpftp + $https) / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($redundancy == 'nplus1') {
			$qty++;
		}
		
		$totalprice = ( $qty * $price ); 
		$totalru = ($qty * $rackunits);
		$totalmaxpower = ($qty * $maxpower);
		
		if ($redpower == 0) {
			$redundantpower = 'no';
		}
		else {
			$redundantpower = "yes";
		}
		
		echo $qty . "," . $partnumber . "," . $totalprice . "<br>";	
	}
} 

/*sg fwd display logic standard output */

if (isset($_POST['SGfwdsubmit'])) {
	$sizingbasis = $_POST['sizingbasis'];
	$httpftp = $_POST['httpftp'];
	$https = $_POST['https'];
	$concurrentsizing = $_POST['concurrentusers'];
	$userssizing = $_POST['users'];
	$tpssizing = $_POST['tps'];
	$redundancy = $_POST['redundancy'];
	$features = $_POST['features'];
	$sizing = $_POST['sizing'];
	$currentpercent = $_POST['currentpercent'];
	$futuregrowth = $_POST['futuregrowth'];
	$futureyears = $_POST['futureyears'];
	$futurepercent = $_POST['futurepercent'];
	$codeversion = $_POST['codeversion'];
	$outputcols = $_POST['outputcols'];
	$output_form = false;
	
	/*
	echo 'HTTP/FTP input is:' . $httpftp;
	echo '<br>HTTPS selected is:' . $https;
	echo '<br>Feature selected is:' . $features;
	echo '<br>Redundancy selected is:' . $redundancy;
	echo '<br>Sizing selected is:' . $sizing;
	echo '<br>Current Percent selected is:' . $currentpercent;
	echo '<br>Future Growth selected is:' . $futuregrowth;
	echo '<br>Future Years selected is:' . $futureyears;
	echo '<br>Future Percent selected is:' . $futurepercent; 
	echo '<br>outputcols is:' . $outputcols; 
	*/
	
	/*foreach ($outputcols as $o) {
	echo '<br>outputcol selected is:' . $o; 
	}*/
	
echo "<center><H3>&nbsp;</H3></center>";  
	echo "<center><p><a href=\"./sizingtoolfwd.php\">Back for new sizing</a></p></center>"; 
	echo "<table width=\"500\" align=\"center\" class=\"nb\">";
	echo "<tr class=\"nb\">";
	echo "<td class=\"titlebar\">";
	echo "&nbsp;&nbsp;&nbsp;ProxySG Sizing Tool";
	echo "</td>";
	echo "</tr>";
	echo "<tr class=\"nb\">";
	echo "<td class=\"nb\">";
	echo "<div id=\"wrapper2\">";
	echo "<h2>Forward Proxy Sizing Data</h2>";
 
    echo "<table class=\"sortable\" width=\"1000\" align=\"center\">";
	
	echo "<tr>";
	
foreach ($outputcols as $o) {
	
	if ($o == qty) {
	echo "<td>";
	echo "<b title=\"Qty\">Qty</b>";	
	echo "</td>";
	}
	if ($o == model) {
	echo "<td>";
	echo "<b title=\"Model\">Model</b>";	
	echo "</td>";
	}
	if ($o == partnum) {
	echo "<td>";
	echo "<b title=\"Part Number\">Part Number</b>";	
	echo "</td>";
	}
	if ($o == totalprice) {
	echo "<td>";
	echo "<b title=\"Total Price\">Total Price</b>";	
	echo "</td>";
	}
	if ($o == tput) {
	echo "<td>";
	echo "<b title=\"Throughput (Mbps) per Unit\">Throughput (Mbps) per Unit</b>";	
	echo "</td>";
	}
	if ($o == totaltpu) {
	echo "<td>";
	echo "<b title=\"Total Throughput (Mbps)\">Total Throughput (Mbps)</b>";	
	echo "</td>";
	}
	if ($o == tps) {
	echo "<td>";
	echo "<b title=\"Transactions per Second\">TPS</b>";	
	echo "</td>";
	}
	if ($o == totaltps) {
	echo "<td>";
	echo "<b title=\"Total Transactions per Second\">Total TPS</b>";	
	echo "</td>";
	}
	if ($o == totalusers) {
	echo "<td>";
	echo "<b title=\"Total Users\">Total Users</b>";	
	echo "</td>";
	}
	if ($o == totalworkers) {
	echo "<td>";
	echo "<b title=\"Total Workers\">Total Workers</b>";	
	echo "</td>";
	}
	if ($o == totalru) {
	echo "<td>";
	echo "<b title=\"Total Rack Units\">Total Rack Units</b>";	
	echo "</td>";
	}
	if ($o == totalpower) {
	echo "<td>";
	echo "<b title=\"Total Max Power\">Total Max Power</b>";	
	echo "</td>";
	}
	if ($o == redundant) {
	echo "<td>";
	echo "<b title=\"Redundant Power\">Redundant Power</b>";	
	echo "</td>";
	}
}	
echo "</tr>";
	
$dbc = mysqli_connect('127.0.0.1', 'root', 'big1blue', 'perfmatrix')
		or die('Error connecting to MySQL server.');
		
	$query = "SELECT * FROM fwd";
	$result = mysqli_query($dbc, $query)
		or die('Error querying database.');
		
	while ($row = mysqli_fetch_array($result)) {
		$model = $row['model'];
		$sgos = $row['sgos'];
		$partnumber = $row['part number'];
		$price = $row['price'];
		$users = $row['users'];
		$http = $row['http'];
		$httppolicy = $row['httppolicy'];
		$httppolicyicap = $row['httppolicyicap'];
		$httppolicyicaphttps = $row['httppolicyicaphttps'];
		$httptps = $row['httptps'];
		$httppolicytps = $row['httppolicytps'];
		$httppolicyicaptps = $row['httppolicyicaptps'];
		$httppolicyicaphttpstps = $row['httppolicyicaphttpstps'];
		$maxobjects = $row['max objects'];
		$maxclientconnections = $row['max client connections'];
		$maxpower = $row['max power'];
		$idlepower = $row['idle power'];
		$redpower = $row['redundant power'];
		$rackunits = $row['rack units'];
/*		echo '<br>model is:' . $model; 
		echo '<br>sgos is:' . $sgos;
		echo '<br>partnumber is:' . $partnumber;
		echo '<br>price is:' . $price;
		echo '<br>users is:' . $users;
		echo '<br>http is:' . $http;
		echo '<br>httppolicy is:' . $httppolicy;
		echo '<br>httppolicyicap is:' . $httppolicyicap;
		echo '<br>httppolicyicaphttps is:' . $httppolicyicaphttps;
		echo '<br>httptps is:' . $httptps;
		echo '<br>httppolicytps is:' . $httppolicytps;
		echo '<br>httppolicyicaptps is:' . $httppolicyicaptps;
		echo '<br>httppolicyicaphttpstps is:' . $httppolicyicaphttpstps;
		echo '<br>maxobjects is:' . $maxobjects;
		echo '<br>maxclientconnections is:' . $maxclientconnections;
		echo '<br>maxpower is:' . $maxpower;
		echo '<br>idlepower is:' . $idlepower;
		echo '<br>redpower is:' . $redpower;
		echo '<br>rackunits is:' . $rackunits; */
		
		/*this is the main logic*/
		
		$calculatedconnections = ((($concurrentsizing * $percentactive) * $activeconn) + (($concurrentsizing * $percentidle) * $idleconn));
		
		if ($codeversion == $sgos) { 
		
		if ($sizing == 'future') {
			$currentpercent = ( $futurepercent / (pow((1 + ($futuregrowth / 100)), $futureyears )));
		}
			
		if ($features == 'httponly') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil(($httpftp / $http) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httptps) / ($currentpercent / 70));
			}
			$throughput = $http;
			$totalthroughput = ($qty * $http);
			$tps = $httptps;
			$totaltps = ($qty * $httptps);
		}
		
		if ($features == 'httppolicy') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil(($httpftp / $httppolicy) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httppolicytps) / ($currentpercent / 70));
			}
			$throughput = $httppolicy;
			$totalthroughput = ($qty * $httppolicy);
			$tps = $httppolicytps;
			$totaltps = ($qty * $httppolicytps);
		}
		
		if ($features == 'httppolicyicap') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil(($httpftp / $httppolicyicap) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httppolicyicaptps) / ($currentpercent / 70));
			}
			$throughput = $httppolicyicap;
			$totalthroughput = ($qty * $httppolicyicap);
			$tps = $httppolicyicaptps;
			$totaltps = ($qty * $httppolicyicaptps);
		}
		
		if ($features == 'httppolicyicaphttps') {
			if ($sizingbasis == 'bandwidth'){
				$qty = ceil((($httpftp + $https) / $httppolicyicaphttps) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'concurrentusers'){
				$qty = ceil(($calculatedconnections / $maxclientconnections) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'users'){
				$qty = ceil(($userssizing / $users) / ($currentpercent / 70));
			}
			if ($sizingbasis == 'tps'){
				$qty = ceil(($tpssizing / $httppolicyicaphttpstps) / ($currentpercent / 70));
			}
			$throughput = $httppolicyicaphttps;
			$totalthroughput = ($qty * $httppolicyicaphttps);
			$tps = $httppolicyicaphttpstps;
			$totaltps = ($qty * $httppolicyicaphttpstps);
		}
		
		$totalusers = ($qty * $users);
		$totalworkers = ($qty * $maxclientconnections);
		
		if ($redundancy == 'nplus1') {
			$qty++;
		}
		
		$totalprice = ( $qty * $price ); 
		$totalru = ($qty * $rackunits);
		$totalmaxpower = ($qty * $maxpower);
		
		if ($redpower == 0) {
			$redundantpower = 'no';
		}
		else {
			$redundantpower = "yes";
		}
		
		}
		
		echo "<tr>";
			
	foreach ($outputcols as $o) {
	
	if ($o == qty) {
	echo "<td>";
	echo "<b title=\"Qty\">" . $qty . "</b>";	
	echo "</td>";
	}
	if ($o == model) {
	echo "<td>";
	echo "<b title=\"Model\">" . $model . "</b>";	
	echo "</td>";
	}
	if ($o == partnum) {
	echo "<td>";
	echo "<b title=\"Part Number\">" . $partnumber . "</b>";	
	echo "</td>";
	}
	if ($o == totalprice) {
	echo "<td>";
	echo "<b title=\"Total Price\">" . $totalprice . "</b>";	
	echo "</td>";
	}
	if ($o == tput) {
	echo "<td>";
	echo "<b title=\"Throughput (Mbps) per Unit\">" . $throughput . "</b>";	
	echo "</td>";
	}
	if ($o == totaltpu) {
	echo "<td>";
	echo "<b title=\"Total Throughput (Mbps)\">" . $totalthroughput . "</b>";	
	echo "</td>";
	}
	if ($o == tps) {
	echo "<td>";
	echo "<b title=\"Transactions per Second\">" . $tps . "</b>";	
	echo "</td>";
	}
	if ($o == totaltps) {
	echo "<td>";
	echo "<b title=\"Total Transactions per Second\">" . $totaltps . "</b>";	
	echo "</td>";
	}
	if ($o == totalusers) {
	echo "<td>";
	echo "<b title=\"Max Total Users\">" . $totalusers . "</b>";	
	echo "</td>";
	}
	if ($o == totalworkers) {
	echo "<td>";
	echo "<b title=\"Total Workers\">" . $totalworkers . "</b>";	
	echo "</td>";
	}
	if ($o == totalru) {
	echo "<td>";
	echo "<b title=\"Total Rack Units\">" . $totalru . "</b>";	
	echo "</td>";
	}
	if ($o == totalpower) {
	echo "<td>";
	echo "<b title=\"Total Max Power\">" . $totalmaxpower . "</b>";	
	echo "</td>";
	}
	if ($o == redundant) {
	echo "<td>";
	echo "<b title=\"Redundant Power\">" . $redundantpower . "</b>";	
	echo "</td>";
	}
	
	}
	
	echo "</tr>";
	
	}
	
	mysqli_close($dbc); 
	
	echo "</table>";

	echo "</div>";
	echo "</td>";
	echo "</tr>";
	echo "</table>";
	
	echo '<br>Sizing input type:' . $sizingbasis;
	echo '<br>HTTP/FTP:' . $httpftp;
	echo '<br>HTTPS:' . $https;
	echo '<br>TPS:' . $tpssizing;
	echo '<br>Peak Concurrent User:' . $concurrentsizing;
	echo '<br>Users:' . $userssizing;
	echo '<br>Features:' . $features;
	echo '<br>Redundancy:' . $redundancy;
	echo '<br>Sizing type:' . $sizing;
	echo '<br>Current Percent:' . $currentpercent;
	echo '<br>Future Growth:' . $futuregrowth;
	echo '<br>Future Years:' . $futureyears;
	echo '<br>Future Percent:' . $futurepercent; 
	echo '<br>Code Version:' . $codeversion; 
}

/*AV sizing output logic*/

if (isset($_POST['AVfwdsubmit'])) {
	$httpftp = $_POST['httpftp'];
	$https = $_POST['https'];
	$redundancy = $_POST['redundancy'];
	$features = $_POST['features'];
	$sizing = $_POST['sizing'];
	$currentpercent = $_POST['currentpercent'];
	$futuregrowth = $_POST['futuregrowth'];
	$futureyears = $_POST['futureyears'];
	$futurepercent = $_POST['futurepercent'];
	$codeversion = $_POST['codeversion'];
	$outputcols = $_POST['outputcols'];
	$output_form = false;
	
	/*
	echo 'HTTP/FTP input is:' . $httpftp;
	echo '<br>HTTPS selected is:' . $https;
	echo '<br>Feature selected is:' . $features;
	echo '<br>Redundancy selected is:' . $redundancy;
	echo '<br>Sizing selected is:' . $sizing;
	echo '<br>Current Percent selected is:' . $currentpercent;
	echo '<br>Future Growth selected is:' . $futuregrowth;
	echo '<br>Future Years selected is:' . $futureyears;
	echo '<br>Future Percent selected is:' . $futurepercent; 
	echo '<br>outputcols is:' . $outputcols; 
	*/
	
	/*foreach ($outputcols as $o) {
	echo '<br>outputcol selected is:' . $o; 
	}*/
	
echo "<center><H3>&nbsp;</H3></center>";  
	echo "<center><p><a href=\"./sizingtoolfwd.php\">Back for new sizing</a></p></center>"; 
	echo "<table width=\"500\" align=\"center\" class=\"nb\">";
	echo "<tr class=\"nb\">";
	echo "<td class=\"titlebar\">";
	echo "&nbsp;&nbsp;&nbsp;ProxyAV Sizing Tool";
	echo "</td>";
	echo "</tr>";
	echo "<tr class=\"nb\">";
	echo "<td class=\"nb\">";
	echo "<div id=\"wrapper2\">";
	echo "<h2>ProxyAV Sizing Data</h2>";
 
    echo "<table class=\"sortable\" width=\"1000\" align=\"center\">";
	
	echo "<tr>";
	
foreach ($outputcols as $o) {
	
	if ($o == qty) {
	echo "<td>";
	echo "<b title=\"Qty\">Qty</b>";	
	echo "</td>";
	}
	if ($o == model) {
	echo "<td>";
	echo "<b title=\"Model\">Model</b>";	
	echo "</td>";
	}
	if ($o == partnum) {
	echo "<td>";
	echo "<b title=\"Part Number\">Part Number</b>";	
	echo "</td>";
	}
	if ($o == totalprice) {
	echo "<td>";
	echo "<b title=\"Total Price\">Total Price</b>";	
	echo "</td>";
	}
	if ($o == tput) {
	echo "<td>";
	echo "<b title=\"Throughput (Mbps) per Unit\">Throughput (Mbps) per Unit</b>";	
	echo "</td>";
	}
	if ($o == totaltpu) {
	echo "<td>";
	echo "<b title=\"Total Throughput (Mbps)\">Total Throughput (Mbps)</b>";	
	echo "</td>";
	}
	if ($o == totalru) {
	echo "<td>";
	echo "<b title=\"Total Rack Units\">Total Rack Units</b>";	
	echo "</td>";
	}
	if ($o == totalpower) {
	echo "<td>";
	echo "<b title=\"Total Max Power\">Total Max Power</b>";	
	echo "</td>";
	}
	if ($o == redundant) {
	echo "<td>";
	echo "<b title=\"Redundant Power\">Redundant Power</b>";	
	echo "</td>";
	}
}	
echo "</tr>";
	
$dbc = mysqli_connect('127.0.0.1', 'root', 'big1blue', 'perfmatrix')
		or die('Error connecting to MySQL server.');
		
	$query = "SELECT * FROM av";
	$result = mysqli_query($dbc, $query)
		or die('Error querying database.');
		
	while ($row = mysqli_fetch_array($result)) {
		$model = $row['model'];
		$partnumber = $row['part'];
		$tput = $row['tput'];
		$price = $row['price'];
		$rackunits = $row['ru'];
		$maxpower = $row['max power'];
		$redpower = $row['redundant'];
		
		/*this is the main logic*/
		
		if ($sizing == 'future') {
			$currentpercent = ( $futurepercent / (pow((1 + ($futuregrowth / 100)), $futureyears )));
		}
			
		if ($features == 'httponly') {
			$qty = ceil(($httpftp / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($features == 'httppolicy') {
			$qty = ceil(($httpftp / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($features == 'httppolicyicap') {
			$qty = ceil(($httpftp / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($features == 'httppolicyicaphttps') {
			$qty = ceil((($httpftp + $https) / $tput) / ($currentpercent / 100));
			$throughput = $tput;
			$totalthroughput = ($qty * $tput);
		}
		
		if ($redundancy == 'nplus1') {
			$qty++;
		}
		
		$totalprice = ( $qty * $price ); 
		$totalru = ($qty * $rackunits);
		$totalmaxpower = ($qty * $maxpower);
		
		if ($redpower == 0) {
			$redundantpower = 'no';
		}
		else {
			$redundantpower = "yes";
		}
		
		echo "<tr>";
			
	foreach ($outputcols as $o) {
	
	if ($o == qty) {
	echo "<td>";
	echo "<b title=\"Qty\">" . $qty . "</b>";	
	echo "</td>";
	}
	if ($o == model) {
	echo "<td>";
	echo "<b title=\"Model\">" . $model . "</b>";	
	echo "</td>";
	}
	if ($o == partnum) {
	echo "<td>";
	echo "<b title=\"Model\">" . $partnumber . "</b>";	
	echo "</td>";
	}
	if ($o == totalprice) {
	echo "<td>";
	echo "<b title=\"Total Price\">" . $totalprice . "</b>";	
	echo "</td>";
	}
	if ($o == tput) {
	echo "<td>";
	echo "<b title=\"Throughput (Mbps) per Unit\">" . $throughput . "</b>";	
	echo "</td>";
	}
	if ($o == totaltpu) {
	echo "<td>";
	echo "<b title=\"Total Throughput (Mbps)\">" . $totalthroughput . "</b>";	
	echo "</td>";
	}
	if ($o == totalru) {
	echo "<td>";
	echo "<b title=\"Total Rack Units\">" . $totalru . "</b>";	
	echo "</td>";
	}
	if ($o == totalpower) {
	echo "<td>";
	echo "<b title=\"Total Max Power\">" . $totalmaxpower . "</b>";	
	echo "</td>";
	}
	if ($o == redundant) {
	echo "<td>";
	echo "<b title=\"Redundant Power\">" . $redundantpower . "</b>";	
	echo "</td>";
	}
	
	}
	
	echo "</tr>";
	
	}
	
	mysqli_close($dbc); 
	
	echo "</table>";

	echo "</div>";
	echo "</td>";
	echo "</tr>";
	echo "</table>";
	
	echo '<br>HTTP/FTP:' . $httpftp;
	echo '<br>HTTPS:' . $https;
	echo '<br>Features:' . $features;
	echo '<br>Redundancy:' . $redundancy;
	echo '<br>Sizing type:' . $sizing;
	echo '<br>Current Percent:' . $currentpercent;
	echo '<br>Future Growth:' . $futuregrowth;
	echo '<br>Future Years:' . $futureyears;
	echo '<br>Future Percent:' . $futurepercent; 
	echo '<br>Code Version:' . $codeversion; 
}

	if ($output_form){
?>

<center>
<a href="./sizingtool.html"><body>ProxySG Sizing Tools Home</body></a>
<H3>&nbsp;</H3></center>
  
<table width="500" align="center" class="nb">

<tr class="nb">
<td class="nb">
<center>
&nbsp;&nbsp;&nbsp;<img src="bcimages/bluecoatLogo.gif" alt="Bluecoat Logo" />
</center>
</td>
</tr>

<tr class="nb">
<td class="titlebar">
<center>
&nbsp;&nbsp;&nbsp;ProxySG Forward Proxy Sizing Tool
</center>
</td>
</tr>

<tr class="nb">
<td class="nb">
<div id=wrapper2>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<input name="sizingbasis" type="radio" value="bandwidth" title="Bandwidth taken should be peak average." checked/> Bandwidth (only option for AV)
<?php
if (isset($_POST['SGfwdextractor'])) {
	$httpftp = $_POST['httpftp'];
	$https = $_POST['https'];
	echo "<br>HTTP and FTP Peak Sustained (Mbps): <input name=\"httpftp\" type=\"text\" size=\"7\" value=\"" . $httpftp . " \" />";
	echo "<br>HTTPS Peak Sustained (Mbps): <input name=\"https\" type=\"text\" size=\"7\" value=\"" . $https . " \" />";
}
else {
	?>
	<br>HTTP and FTP Peak Sustained (Mbps): <input name="httpftp" type="text" size="7"/>
	<br>HTTPS Peak Sustained (Mbps): <input name="https" type="text" size="7"/>
	<?php
}
	?>
<br>
<br><input name="sizingbasis" type="radio" value="tps" title="tps is Transactions per Second (NOT concurrent connections)." /> Transactions per Second
<input name="tps" type="text" size="20"/>
<br>
<br><input name="sizingbasis" type="radio" value="concurrentusers" title="peak concurrent users taken off SG or Firewall" /> Peak Concurrent Users 
<input name="concurrentusers" type="text" size="7"/>
<br>
<br><input name="sizingbasis" type="radio" value="users" title="Users is based on number of users in an organization NOT concurrent users.  User is the least accurate measure and more margin for error should be used if sizing based on users." /> Total Users 
<input name="users" type="text" size="7"/>
<br>
<center>
&nbsp;&nbsp;&nbsp;
<br>
<b>Features</b>
</center>
<br><input name="features" type="radio" value="httponly" /> HTTP only
<br><input name="features" type="radio" value="httppolicy" checked/> HTTP + Standard Policy
<br><input name="features" type="radio" value="httppolicyicap" /> HTTP + Standard Policy + ICAP
<br><input name="features" type="radio" value="httppolicyicaphttps" /> HTTP + Standard Policy + ICAP + HTTPS (15%)
<br>
<center>
&nbsp;&nbsp;&nbsp;
<br>
<b>Design</b>
</center>
<br><input name="redundancy" type="checkbox" value="nplus1" /> N + 1 Redundancy
<br>
<br><input name="sizing" type="radio" value="current" checked/> Current Sizing
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<select name="currentpercent">
	<option value="10">10%</option>
	<option value="20">20%</option>
	<option value="30">30%</option>
	<option value="40">40%</option>
	<option value="50" selected="selected">50%</option>
	<option value="60">60%</option>
	<option value="70">70%</option>
	<option value="80">80% - not recommended</option>
	<option value="90">90% - not recommended</option>
</select>
<i>utilization % at installation time</i>
<br><input name="sizing" type="radio" value="future" /> Future Growth Sizing
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="futuregrowth" size="5">
<i> % of Growth per Year</i>
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="futureyears" size="5">
<i> # of Years</i>
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<select name="futurepercent">
	<option value="10">10%</option>
	<option value="20">20%</option>
	<option value="30">30%</option>
	<option value="40">40%</option>
	<option value="50" selected="selected">50%</option>
	<option value="60">60%</option>
	<option value="70">70%</option>
	<option value="80">80% - not recommended</option>
	<option value="90">90% - not recommended</option>
</select>
<i>utilization % at end of # of years</i>
<br>
<center>
&nbsp;&nbsp;&nbsp;
<br>
<b>General Settings</b>
</center>
<br>Code Version
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<select name="codeversion">
	<option value="6.2" selected="selected">6.2</option>
	<option value="6.3">6.3 - not yet implemented</option>
</select>
<br>
<br>Output Columns
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<center>
<table>
<tr>
<td>
<input type="checkbox" name="outputcols[ ]" value="qty" checked="checked">Qty
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="model" checked="checked">Model
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="partnum">Part Number
</td>
</tr>
<tr>
<td>
<input type="checkbox" name="outputcols[ ]" value="price">Price per Unit
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="totalprice" checked="checked">Total Price
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="tput">Throughput per Unit
</td>
</tr>
<tr>
<td>
<input type="checkbox" name="outputcols[ ]" value="totaltpu" checked="checked">Total Throughput
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="tps">TPS
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="totaltps">Total TPS
</td>
</tr>
<tr>
<td>
<input type="checkbox" name="outputcols[ ]" value="totalusers" checked="checked">Total Users
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="totalworkers">Total Workers
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="totalru" checked="checked">Total RU
</td>
</tr>
<tr>
<td>
<input type="checkbox" name="outputcols[ ]" value="totalpower" checked="checked">Total Max Power
</td>
<td>
<input type="checkbox" name="outputcols[ ]" value="redundant" checked="checked">Redundant Power
</td>
</tr>
</table>
<br><input type="submit" name="SGfwdsubmit" value="SG Sizing" />
<input type="submit" name="AVfwdsubmit" value="AV Sizing" />
<input type="submit" name="SGfwdcsvsubmit" value="SG Sizing CSV" />
<input type="submit" name="AVfwdcsvsubmit" value="AV Sizing CSV" />
</center>
</form>
</div>
</td>
</tr>

</table>

<?php
}

echo "</body>";
echo "</html>";

?>



